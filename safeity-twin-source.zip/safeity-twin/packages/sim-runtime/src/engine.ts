/**
 * SimEngine — runs inside a Web Worker (or in Node for tests). Owns the twin, the
 * navigation graph, the shared hazard field and every engine, and advances them on
 * a fixed 0.5 s tick. Deterministic for a given scenario seed.
 */
import { Rng } from '@twin/core';
import { FieldStore, type HazardInstance, type HazardPlugin, type SimContext, type SimEvent } from '@twin/hazard-sdk';
import type { HazardSpec, Scenario, SiteDataset } from '@twin/twin-schema';
import { buildTwin, type Twin } from '@twin/twin-data';
import { buildNavGraph, type NavGraph } from '@twin/nav';
import { Evacuation } from '@twin/crowd';
import { Dispatcher } from '@twin/dispatch';
import { recommend, type Recommendation } from '@twin/advisor';
import { hazards } from './registry';
import type { Snapshot, StartOptions } from './protocol';

export const TICK = 0.5;

export class SimEngine {
  readonly twin: Twin;
  readonly nav: NavGraph;
  field!: FieldStore;
  evac!: Evacuation;
  dispatch!: Dispatcher;
  rng = new Rng(1);
  t = 0;
  running = false;
  speed = 1;
  scenario: Scenario | null = null;
  private active: { spec: HazardSpec; plugin: HazardPlugin; inst: HazardInstance }[] = [];
  private queue: HazardSpec[] = [];
  private events: SimEvent[] = [];
  private outbox: SimEvent[] = [];
  private recs: Recommendation[] = [];
  private nextAdvice = 0;
  private lastStepMs = 0;
  readonly buildMs: number;

  constructor(readonly ds: SiteDataset) {
    const t0 = performance.now();
    this.twin = buildTwin(ds);
    this.nav = buildNavGraph(this.twin);
    this.buildMs = performance.now() - t0;
    this.reset(null, { launchedOnly: false });
  }

  private ctx(): SimContext {
    return {
      twin: this.twin,
      field: this.field,
      rng: this.rng,
      t: this.t,
      wind: this.scenario?.wind ?? { speed_ms: 4, fromDeg: 250 },
      emit: (ev) => {
        const e = { ...ev, t: this.t };
        this.events.push(e);
        this.outbox.push(e);
      },
      spawn: (spec) => this.queue.push({ ...spec, t: Math.max(spec.t, this.t) }),
      alert: (wings, _reason, delay = 120) => this.evac.alert(wings, this.t, delay),
      alertAll: (_reason, delay = 60) => this.evac.alertAll(this.t, delay),
    };
  }

  reset(scenario: Scenario | null, options: StartOptions): void {
    this.scenario = scenario;
    this.rng = new Rng(scenario?.seed ?? 1);
    this.t = 0;
    this.field = new FieldStore(this.twin);
    this.evac = new Evacuation(this.twin, this.nav, this.ds, scenario?.occupancy ?? 'weekday-night', this.rng.fork(7), options);
    this.dispatch = new Dispatcher(this.twin, this.nav, this.ds, scenario?.resources ?? {});
    this.active = [];
    this.queue = scenario ? [...scenario.hazards] : [];
    this.events = [];
    this.outbox = [];
    this.recs = [];
    this.nextAdvice = 0;
  }

  start(scenario: Scenario, options: StartOptions): void {
    this.reset(scenario, options);
    this.running = true;
  }

  inject(spec: HazardSpec): void {
    this.queue.push({ ...spec, t: this.t });
  }

  private spawnDue(ctx: SimContext) {
    const due = this.queue.filter((q) => q.t <= this.t);
    this.queue = this.queue.filter((q) => q.t > this.t);
    for (const spec of due) {
      const plugin = hazards.get(spec.type);
      if (!plugin || !plugin.enabled) {
        ctx.emit({ type: 'error', level: 'warn', text: `Hazard "${spec.type}" is not available yet` });
        continue;
      }
      try {
        const inst = plugin.create(ctx, spec);
        this.active.push({ spec, plugin, inst });
      } catch (e) {
        ctx.emit({ type: 'error', level: 'warn', text: `${plugin.label}: ${(e as Error).message}` });
      }
    }
  }

  step(dt = TICK): void {
    const t0 = performance.now();
    this.t += dt;
    const ctx = this.ctx();
    this.spawnDue(ctx);
    for (const h of this.active) h.inst.step(dt, ctx);
    this.field.updateTenability();
    this.evac.step(dt, ctx);
    this.dispatch.step(dt, ctx, this.evac);
    if (this.t >= this.nextAdvice) {
      this.nextAdvice = this.t + 2;
      this.recs = recommend({ twin: this.twin, field: this.field, t: this.t, evac: this.evac, dispatch: this.dispatch, hazards: this.active.map((h) => h.spec.type) });
    }
    this.lastStepMs = performance.now() - t0;
  }

  snapshot(): Snapshot {
    const f = this.field;
    const ids: number[] = [];
    for (const w of f.activeWings) {
      const wing = this.twin.wings[w];
      if (wing.massingOnly) continue;
      const start = wing.storeyOffsets[0];
      for (let i = start; i < start + wing.spaceCount; i++) {
        if (f.soot[i] > 0.02 || f.burn[i] > 0 || f.damage[i] > 0 || f.temp[i] > 45) ids.push(i);
      }
    }
    const n = ids.length;
    const spaces = { ids: Int32Array.from(ids), soot: new Float32Array(n), temp: new Float32Array(n), burn: new Uint8Array(n), damage: new Uint8Array(n) };
    let burning = 0;
    let hrr = 0;
    let smoky = 0;
    ids.forEach((g, k) => {
      spaces.soot[k] = f.soot[g];
      spaces.temp[k] = f.temp[g];
      spaces.burn[k] = f.burn[g];
      spaces.damage[k] = f.damage[g];
      if (f.burn[g] === 1 || f.burn[g] === 2) burning++;
      hrr += f.hrr[g];
      if (f.visibility(g) < 10) smoky++;
    });
    const damage = [0, 0, 0, 0, 0];
    for (const w of this.twin.wings) if (!w.massingOnly) damage[f.wingDamage[w.idx]]++;
    const blocked: number[] = [];
    f.blockedStreet.forEach((b, i) => b && blocked.push(i));
    const events = this.outbox;
    this.outbox = [];
    return {
      t: this.t,
      running: this.running,
      speed: this.speed,
      spaces,
      wingDamage: Uint8Array.from(f.wingDamage),
      groups: this.evac.pack(),
      resources: this.dispatch.pack(),
      routes: this.evac.sampleRoutes(),
      events,
      recommendations: this.recs,
      assignments: this.dispatch.assignments,
      pending: this.dispatch.pending,
      evac: this.evac.kpis(),
      fire: { burningRooms: burning, hrr_MW: Math.round(hrr / 100) / 10, smokeSpaces: smoky },
      damage,
      blockedStreets: blocked,
      debris: f.debris,
      hazards: this.active.map((h) => ({ type: h.spec.type, label: h.plugin.label, summary: h.inst.summary?.() ?? {} })),
      liftsOn: f.liftsOn,
      powerOn: f.powerOn,
      stepMs: Math.round(this.lastStepMs * 10) / 10,
    };
  }

  allEvents(): SimEvent[] {
    return this.events;
  }
}
