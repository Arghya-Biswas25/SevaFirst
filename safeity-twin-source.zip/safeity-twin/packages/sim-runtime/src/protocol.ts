import type { HazardSpec, Scenario, SiteDataset } from '@twin/twin-schema';
import type { DebrisZone, SimEvent } from '@twin/hazard-sdk';
import type { EvacKpis } from '@twin/crowd';
import type { Assignment, ResourceStatus } from '@twin/dispatch';
import type { Recommendation } from '@twin/advisor';

export interface StartOptions {
  launchedOnly: boolean;
}

export type ToWorker =
  | { type: 'init'; ds: SiteDataset }
  | { type: 'start'; scenario: Scenario; options: StartOptions }
  | { type: 'pause' }
  | { type: 'resume' }
  | { type: 'speed'; value: number }
  | { type: 'inject'; spec: HazardSpec }
  | { type: 'alertAll' }
  | { type: 'stop' };

export interface Snapshot {
  t: number;
  running: boolean;
  speed: number;
  spaces: { ids: Int32Array; soot: Float32Array; temp: Float32Array; burn: Uint8Array; damage: Uint8Array };
  wingDamage: Uint8Array;
  groups: Float32Array;
  resources: { id: string; kind: string; status: ResourceStatus; E: number; N: number; route: [number, number, number][] }[];
  routes: [number, number, number][][];
  events: SimEvent[];
  recommendations: Recommendation[];
  assignments: Assignment[];
  pending: { task: string; label: string; reason: string; people: number }[];
  evac: EvacKpis;
  fire: { burningRooms: number; hrr_MW: number; smokeSpaces: number };
  damage: number[];
  blockedStreets: number[];
  debris: DebrisZone[];
  hazards: { type: string; label: string; summary: Record<string, number | string> }[];
  liftsOn: boolean;
  powerOn: boolean;
  stepMs: number;
}

export type FromWorker =
  | { type: 'ready'; stats: { spaces: number; flats: number; navNodes: number; navEdges: number; buildMs: number } }
  | { type: 'snapshot'; snap: Snapshot }
  | { type: 'error'; message: string };
