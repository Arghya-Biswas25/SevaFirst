# Build status — Milestone 1

## Delivered

* **Twin:** 54 wings, 2 hotel arms (massing), 1,912 flats (992 launched), 20,838 rooms and spaces, 29,860
  openings, stairs and lifts, from L1 data. Exterior shells with windows, balconies, stilts and roof headrooms;
  interiors with coloured floors, walls with door openings, stair flights and lift cars.
* **Viewing:** orbit, hover (ghost or solid), walk with collisions and floor changes, X-ray, interiors, storey
  cut, hover read-out of any room, inspector with live conditions.
* **Right-click simulation:** fire, building collapse, earthquake and power failure, with forms generated from
  plugin parameters, multi-hazard scenarios, injection into a running simulation, run settings (occupancy,
  launched phases only, responders available, wind, seed). Nine roadmap hazards are listed and disabled.
* **Evacuation:** every household routed by convenience (smoke, heat, damage, congestion, door and stair
  capacity), capacity-aware assembly points, shelter-in-place when no tenable route exists.
* **Dispatch:** Hungarian assignment re-solved every 5 s with reasons, next-best alternatives, mutual aid
  call-in and stand-down, debris crossing on foot, and a list of tasks waiting for a unit.
* **Advice:** prioritised recommendations with the reason and source.
* **Engineering:** simulation in a Web Worker with an inline fallback, deterministic seeds, 15 tests.

## Verified

* PRD example "two fires, one tender": the on-site tender goes to R17-B first because 39 people above the
  fire floor depend on its only stair; mutual aid is called and later reassigned to R13.
* MCE earthquake, holiday peak: damage, blocked streets, post-quake gas fires, rescues; average step 7–10 ms.
* Production build renders in headless Chromium (software GL) at desktop and phone widths without horizontal
  overflow.

## Known limits

* L1 geometry: positions ±5 m, bearings ±2°, interiors generated from unit types rather than drawn plans.
* Fire is a zone model (hot layer, soot, door and window spread), not CFD. Structural fragility medians for the
  earthquake are placeholders until calibrated against the structural drawings. The NBC rule pack is unverified.
* Holiday-peak population exceeds the five assembly points' combined capacity; the model spreads the overflow
  and the advisor flags it.
* Walk mode changes floor with PgUp/PgDn rather than climbing the stair flights.
* No saved scenarios, sharing of runs, or multi-user sessions yet (PRD milestones 2–3).
* Frame rates were measured with software rendering only; check on the target hardware.
