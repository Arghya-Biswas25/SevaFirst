import { Bar, Chip, Empty, Icon, Kpi, Section } from '@twin/ui-kit';
import type { Snapshot } from '@twin/sim-runtime';
import type { SimEvent } from '@twin/hazard-sdk';
import { STATUS_COLORS } from '@twin/render';
import { ds, twin } from '../app/core';
import { fmtEta, fmtInt, fmtTime, title } from '../app/format';

const KIND_ICON: Record<string, string> = { fire_tender: 'truck', ambulance: 'medical', rescue_team: 'collapse', security_team: 'people', warden_team: 'bell', technician: 'power' };
const STATUS_TONE: Record<string, 'good' | 'warn' | 'bad' | 'info' | 'muted'> = { offsite: 'muted', called: 'warn', standby: 'muted', enroute: 'info', onscene: 'good' };

export function ResponsePanel({ snap, onFocusWing }: { snap: Snapshot | null; onFocusWing: (wing: number) => void }) {
  if (!snap) return <Empty icon="truck">Start a simulation to see responder dispatch and recommendations.</Empty>;
  const specs = new Map(ds.resources.resources.map((r) => [r.id, r]));
  const assigned = new Map(snap.assignments.map((a) => [a.resource, a]));
  const recs = [...snap.recommendations].sort((a, b) => a.priority - b.priority);
  return (
    <div>
      <Section title={<>Dispatch <span className="muted small">· re-optimised every 5 s</span></>}>
        {snap.assignments.length === 0 && <p className="muted small">No tasks yet. Units stay on standby until an alarm creates work.</p>}
        <ul className="dispatch">
          {snap.assignments.map((a) => {
            const w = twin.wings.find((x) => a.taskLabel.includes(x.id));
            return (
              <li key={a.resource + a.task} onClick={() => w && onFocusWing(w.idx)} className={w ? 'clickable' : ''}>
                <div className="d-top">
                  <Icon name={KIND_ICON[a.kind] ?? 'truck'} />
                  <b>{a.resourceName}</b>
                  <Chip tone={STATUS_TONE[a.status]}>{a.status === 'onscene' ? 'on scene' : a.status}</Chip>
                  <span className="eta">{a.status === 'onscene' ? '' : `ETA ${fmtEta(a.eta_s)}`}</span>
                </div>
                <div className="d-task">→ {a.taskLabel}</div>
                <div className="d-why"><Icon name="bulb" size={12} /> {a.reason}</div>
                {a.runnerUp && <div className="d-alt">Next best: {a.runnerUp}</div>}
              </li>
            );
          })}
        </ul>
        {snap.pending.length > 0 && (
          <div className="pending">
            <h4>Waiting for a unit ({snap.pending.length})</h4>
            <ul>
              {snap.pending.slice(0, 8).map((p) => (
                <li key={p.task}><b>{p.label}</b><span>{p.reason}</span></li>
              ))}
            </ul>
          </div>
        )}
        <table className="units-table">
          <tbody>
            {snap.resources.map((r) => (
              <tr key={r.id} className={assigned.has(r.id) ? '' : 'idle'}>
                <td><Icon name={KIND_ICON[r.kind] ?? 'truck'} size={13} /></td>
                <td>{specs.get(r.id)?.name ?? r.id}</td>
                <td><Chip tone={STATUS_TONE[r.status]}>{r.status === 'onscene' ? 'on scene' : r.status}</Chip></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>
      <Section title={<>Recommendations <span className="muted small">· {recs.length}</span></>}>
        {recs.length === 0 && <p className="muted small">Nothing to flag right now.</p>}
        <ul className="recs">
          {recs.map((r) => (
            <li key={r.id} className={`p${r.priority}`}>
              <div className="r-title"><span className="r-pri">P{r.priority}</span>{r.title}</div>
              <div className="r-detail">{r.detail}</div>
              <div className="r-why"><b>Why:</b> {r.reason}</div>
              <div className="r-src">{r.source}</div>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}

const STATUS_LABEL: [string, string][] = [
  ['waiting', 'Waiting (pre-movement)'], ['moving', 'Moving'], ['queued', 'Queued at a door or stair'], ['sheltering', 'Sheltering in place'],
  ['trapped', 'Trapped'], ['casualty', 'Casualties'], ['safe', 'Safe at assembly'], ['rescued', 'Rescued'],
];
const STATUS_INDEX: Record<string, number> = { idle: 0, waiting: 1, moving: 2, queued: 3, sheltering: 4, trapped: 5, casualty: 6, safe: 7, rescued: 8 };

export function EvacPanel({ snap }: { snap: Snapshot | null }) {
  if (!snap) return <Empty icon="people">Evacuation figures appear once a simulation runs.</Empty>;
  const e = snap.evac;
  const b = e.byStatus;
  const out = b.safe + b.rescued;
  return (
    <div>
      <div className="kpis k3">
        <Kpi label="People on site" value={fmtInt(e.persons)} tone="info" />
        <Kpi label="Alerted" value={fmtInt(e.alerted)} sub={`${e.wingsAlerted} wings`} />
        <Kpi label="Still inside" value={fmtInt(e.inside)} tone={e.inside ? 'warn' : 'good'} />
        <Kpi label="Out and safe" value={fmtInt(out)} tone="good" />
        <Kpi label="Trapped" value={fmtInt(b.trapped)} tone={b.trapped ? 'bad' : 'muted'} />
        <Kpi label="Casualties" value={fmtInt(b.casualty)} tone={b.casualty ? 'bad' : 'muted'} />
      </div>
      <Section title="People by status">
        <ul className="status-list">
          {STATUS_LABEL.map(([k, l]) => (
            <li key={k}>
              <i style={{ background: STATUS_COLORS[STATUS_INDEX[k]] }} />
              <span>{l}</span>
              <b>{fmtInt(b[k as keyof typeof b] ?? 0)}</b>
            </li>
          ))}
        </ul>
      </Section>
      <Section title="Assembly points">
        <ul className="assembly">
          {e.assembly.map((a) => (
            <li key={a.id}>
              <div className="a-top"><b>{a.id}</b><span>{a.name}</span><em>{fmtInt(a.persons)} / {fmtInt(a.capacity)}</em></div>
              <Bar value={a.persons} max={a.capacity} />
            </li>
          ))}
        </ul>
      </Section>
      {e.wingClear.length > 0 && (
        <Section title={`Wing clearance (${e.wingClear.filter((w) => w.clearedAt !== null).length}/${e.wingClear.length} clear)`}>
          <table className="clear-table">
            <thead><tr><th>Wing</th><th>Alerted</th><th>Inside</th><th>Cleared</th></tr></thead>
            <tbody>
              {[...e.wingClear].sort((x, y) => y.inside - x.inside).slice(0, 40).map((w) => (
                <tr key={w.wing}><td>{w.wing}</td><td>{w.alerted}</td><td className={w.inside ? 'warn' : ''}>{w.inside}</td><td>{w.clearedAt !== null ? fmtTime(w.clearedAt) : '—'}</td></tr>
              ))}
            </tbody>
          </table>
        </Section>
      )}
    </div>
  );
}

export function LogPanel({ events, onFocusWing }: { events: SimEvent[]; onFocusWing: (wing: number) => void }) {
  if (!events.length) return <Empty icon="log">The event log fills as the simulation runs: ignitions, alarms, flashover, collapses, dispatch decisions.</Empty>;
  return (
    <ul className="log">
      {[...events].reverse().slice(0, 300).map((e, i) => (
        <li key={i} className={`lv-${e.level}${e.wing !== undefined ? ' clickable' : ''}`} onClick={() => e.wing !== undefined && onFocusWing(e.wing)}>
          <time>{fmtTime(e.t)}</time>
          <span className="tag">{title(e.type)}</span>
          <span className="txt">{e.text}</span>
        </li>
      ))}
    </ul>
  );
}
