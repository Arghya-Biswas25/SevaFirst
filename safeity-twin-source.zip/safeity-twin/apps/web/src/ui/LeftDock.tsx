import { useMemo, useState } from 'react';
import { Button, Chip, Icon, Section, Toggle } from '@twin/ui-kit';
import type { HazardSpec } from '@twin/twin-schema';
import type { LayerName } from '@twin/render';
import { STATUS_COLORS } from '@twin/render';
import { TYPOLOGY_COLORS } from '@twin/geometry';
import { ds, hazards, HAZARD_ICONS, twin } from '../app/core';
import { PRESETS, type Preset } from '../app/scenarios';
import { fmtInt, fmtTime } from '../app/format';
import { wingPersons } from './Inspector';

export interface ViewState {
  xray: boolean;
  interiors: boolean;
  cut: number | null;
  layers: Record<LayerName, boolean>;
}

const LAYER_LABELS: [LayerName, string][] = [
  ['labels', 'Building labels'], ['streets', 'Streets and blocked roads'], ['assembly', 'Assembly points and gates'],
  ['hazards', 'Fire, smoke and heat'], ['people', 'People'], ['routes', 'Evacuation and responder routes'], ['vehicles', 'Responders'],
];

export function ScenariosTab({ running, draft, onPreset, onLoadPreset, onRunDraft, onRemoveDraft, onClearDraft }: {
  running: boolean;
  draft: HazardSpec[];
  onPreset: (p: Preset) => void;
  onLoadPreset: (p: Preset) => void;
  onRunDraft: () => void;
  onRemoveDraft: (i: number) => void;
  onClearDraft: () => void;
}) {
  return (
    <div>
      <div className="hint"><Icon name="target" /> Right-click any room, building or open ground to simulate a hazard there.</div>
      <Section title={`Your scenario${draft.length ? ` (${draft.length})` : ''}`}>
        {draft.length === 0 ? (
          <p className="muted small">Empty. Use "Add to scenario" in the simulation window to stack hazards, for example two fires a few minutes apart.</p>
        ) : (
          <>
            <ul className="draft">
              {draft.map((d, i) => (
                <li key={i}>
                  <Icon name={HAZARD_ICONS[d.type] ?? 'hazard'} className={`hz-${d.type}`} />
                  <span>{hazards.get(d.type)?.label} · {d.origin.label ?? 'site'}</span>
                  <Chip tone="muted">T+{fmtTime(d.t)}</Chip>
                  <button className="uk-x" onClick={() => onRemoveDraft(i)} aria-label="Remove"><Icon name="close" size={12} /></button>
                </li>
              ))}
            </ul>
            <div className="row-btns">
              <Button kind="primary" icon="play" onClick={onRunDraft}>{running ? 'Restart with these' : 'Run scenario'}</Button>
              <Button kind="ghost" onClick={onClearDraft}>Clear</Button>
            </div>
          </>
        )}
      </Section>
      <Section title="Preset scenarios">
        <ul className="presets">
          {PRESETS.map((p) => (
            <li key={p.id}>
              <div className="p-head"><Icon name={p.icon} className={`hz-${p.icon === 'earthquake' ? 'earthquake' : p.icon}`} /><b>{p.title}</b></div>
              <p>{p.blurb}</p>
              <div className="row-btns">
                <Button small kind="primary" icon="play" onClick={() => onPreset(p)}>Run</Button>
                <Button small kind="ghost" onClick={() => onLoadPreset(p)}>Edit</Button>
              </div>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}

export function BuildingsTab({ selected, onPick }: { selected?: number; onPick: (wing: number) => void }) {
  const [q, setQ] = useState('');
  const rows = useMemo(() => {
    const m = new Map<string, number[]>();
    for (const w of twin.wings) {
      const key = w.building.row ? `Row ${w.building.row}` : w.id.startsWith('MU') ? 'Mixed-use' : 'Hotel';
      if (!m.has(key)) m.set(key, []);
      m.get(key)!.push(w.idx);
    }
    return [...m.entries()];
  }, []);
  const stats = useMemo(() => {
    const launched = twin.flats.filter((f) => twin.wings[f.wing].status === 'launched').length;
    return { wings: twin.wings.length, flats: twin.flats.length, launched, spaces: twin.nSpaces };
  }, []);
  const ql = q.trim().toLowerCase();
  return (
    <div>
      <div className="search">
        <Icon name="search" />
        <input placeholder="Find a wing, e.g. R17-B" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="stat-line">{stats.wings} wings · {fmtInt(stats.flats)} flats ({fmtInt(stats.launched)} launched) · {fmtInt(stats.spaces)} rooms and spaces</div>
      {rows.map(([row, wings]) => {
        const list = wings.filter((wi) => !ql || twin.wings[wi].id.toLowerCase().includes(ql) || twin.wings[wi].typology.code.toLowerCase().includes(ql));
        if (!list.length) return null;
        return (
          <div key={row} className="b-row">
            <div className="b-row-h">{row}</div>
            {list.map((wi) => {
              const w = twin.wings[wi];
              return (
                <button key={wi} className={`b-item${selected === wi ? ' on' : ''}`} onClick={() => onPick(wi)}>
                  <i style={{ background: TYPOLOGY_COLORS[w.typology.code] }} />
                  <b>{w.id}</b>
                  <span>{w.typology.code}</span>
                  <span className="muted">{w.flatIds.length ? `${w.flatIds.length} flats · ~${wingPersons(wi)}p` : 'massing'}</span>
                  {w.status !== 'launched' && <Chip tone="muted">{w.status}</Chip>}
                </button>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

export function LayersTab({ view, onView }: { view: ViewState; onView: (v: ViewState) => void }) {
  const typos = Object.values(ds.typologies.typologies);
  return (
    <div>
      <Section title="Show">
        <div className="toggles">
          {LAYER_LABELS.map(([k, l]) => (
            <Toggle key={k} checked={view.layers[k]} label={l} onChange={(on) => onView({ ...view, layers: { ...view.layers, [k]: on } })} />
          ))}
          <Toggle checked={view.interiors} label="Interiors (rooms, walls, stairs)" onChange={(on) => onView({ ...view, interiors: on })} />
          <Toggle checked={view.xray} label="X-ray facades" onChange={(on) => onView({ ...view, xray: on })} />
        </div>
      </Section>
      <Section title="Legend">
        <div className="legend">
          <h4>Typologies</h4>
          {typos.map((t) => (
            <div key={t.code} className="lg"><i style={{ background: TYPOLOGY_COLORS[t.code] }} /><span>{t.code}</span><em>{t.name}</em></div>
          ))}
          <h4>People</h4>
          {['Waiting', 'Moving', 'Queued', 'Sheltering', 'Trapped', 'Casualty', 'Safe', 'Rescued'].map((l, i) => (
            <div key={l} className="lg"><i className="dot" style={{ background: STATUS_COLORS[i + 1] }} /><span>{l}</span></div>
          ))}
          <h4>Hazards and routes</h4>
          <div className="lg"><i style={{ background: '#ff8c14' }} /><span>Burning room</span></div>
          <div className="lg"><i style={{ background: '#73787f' }} /><span>Smoke (darker = thicker)</span></div>
          <div className="lg"><i style={{ background: '#d96b40' }} /><span>Hot gas above 70°C</span></div>
          <div className="lg"><i className="line" style={{ background: '#19c37d' }} /><span>Evacuation route</span></div>
          <div className="lg"><i className="line dash" style={{ color: '#ff3b30' }} /><span>Responder route</span></div>
          <div className="lg"><i style={{ background: '#ff3b30' }} /><span>Blocked street</span></div>
          <div className="lg"><i style={{ background: '#8d7b68' }} /><span>Debris</span></div>
        </div>
      </Section>
      <Section title="Data provenance" defaultOpen={false}>
        <dl className="dl">
          <dt>Site</dt><dd>{ds.site.name} · {ds.site.developer} · {ds.site.location}</dd>
          <dt>Level</dt><dd>{ds.site.dataLevel} — calibrated from the developer's floor-plan brochure</dd>
          <dt>Scale</dt><dd>{String(ds.site.calibration?.masterplan_m_per_image_px ?? '—')} m per master-plan pixel · {String(ds.site.calibration?.floorplan_calibration ?? '')}</dd>
          <dt>Checks</dt><dd>site {String(ds.site.checks?.site_area_acres_measured)} ac measured vs {String(ds.site.checks?.site_area_published_acres)} published · {String(ds.site.checks?.units_inferred_total)} flats inferred vs {String(ds.site.checks?.units_published_total)} published</dd>
          <dt>Tolerance</dt><dd>{Object.entries(ds.site.tolerance ?? {}).map(([k, v]) => `${k.replace('_', ' ')} ±${v}`).join(', ')}</dd>
          <dt>Upgrade</dt><dd>L2 = sanctioned CAD drawings, L3 = as-built survey. Swap the files in data/sites/adora-de-goa; no code changes.</dd>
        </dl>
      </Section>
    </div>
  );
}
