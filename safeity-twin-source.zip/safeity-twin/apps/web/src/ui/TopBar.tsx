import { Button, Chip, Icon, Segmented } from '@twin/ui-kit';
import type { CameraMode } from '@twin/interaction';
import { ds } from '../app/core';
import { fmtTime } from '../app/format';
import type { ViewState } from './LeftDock';

export type SimStatus = 'booting' | 'idle' | 'running' | 'paused';
const SPEEDS = [1, 5, 10, 30, 60];

interface Props {
  cam: CameraMode;
  ghost: boolean;
  storey: number;
  view: ViewState;
  status: SimStatus;
  simT: number;
  speed: number;
  onCam: (m: CameraMode) => void;
  onGhost: () => void;
  onHome: () => void;
  onTop: () => void;
  onView: (v: ViewState) => void;
  onPlayPause: () => void;
  onStop: () => void;
  onSpeed: (s: number) => void;
  onEvacuateAll: () => void;
}

export function TopBar(p: Props) {
  const live = p.status === 'running' || p.status === 'paused';
  return (
    <header className="topbar">
      <div className="brand">
        <div className="logo"><Icon name="building" size={18} /></div>
        <div>
          <div className="brand-name">{ds.site.name} <span>Digital Twin</span></div>
          <div className="brand-sub" title={ds.site.location}><span>{ds.site.location?.split(',')[0]}</span><Chip tone="info">{ds.site.dataLevel} · brochure-calibrated</Chip></div>
        </div>
      </div>
      <div className="tb-group">
        <Segmented value={p.cam} onChange={p.onCam} options={[
          { value: 'orbit', label: 'Orbit', icon: 'orbit', title: 'Site overview (1)' },
          { value: 'fly', label: 'Hover', icon: 'fly', title: 'Fly through and around buildings (2)' },
          { value: 'walk', label: 'Walk', icon: 'walk', title: 'Walk a floor at eye height (3)' },
        ]} />
        {p.cam === 'fly' && <Button small kind="ghost" onClick={p.onGhost} title="G">{p.ghost ? 'Ghost: through walls' : 'Solid: stop at walls'}</Button>}
        {p.cam === 'walk' && <Chip tone="info">Floor {p.storey === 0 ? 'G' : p.storey}</Chip>}
        <Button small kind="ghost" icon="home" onClick={p.onHome} title="Home view" />
        <Button small kind="ghost" icon="plan" onClick={p.onTop} title="Plan view" />
      </div>
      <div className="tb-group">
        <Button small kind="ghost" icon="xray" active={p.view.xray} onClick={() => p.onView({ ...p.view, xray: !p.view.xray })} title="X-ray facades (X)">X-ray</Button>
        <Button small kind="ghost" icon="layers" active={p.view.interiors} onClick={() => p.onView({ ...p.view, interiors: !p.view.interiors })} title="Interiors (I)">Interiors</Button>
        <label className="cut" title="Cut the model above a floor">
          <Icon name="scissors" size={14} />
          <select value={p.view.cut === null ? '' : String(p.view.cut)} onChange={(e) => p.onView({ ...p.view, cut: e.target.value === '' ? null : Number(e.target.value) })}>
            <option value="">No cut</option>
            {[0, 1, 2, 3, 4, 5, 6, 7].map((s) => <option key={s} value={s}>Up to floor {s === 0 ? 'G' : s}</option>)}
          </select>
        </label>
      </div>
      <div className="tb-group sim">
        <Chip tone={p.status === 'running' ? 'good' : p.status === 'paused' ? 'warn' : 'muted'}>{p.status === 'booting' ? 'loading…' : p.status}</Chip>
        <span className="clock" title="Simulated time since the scenario started">T+{fmtTime(p.simT)}</span>
        <Button small icon={p.status === 'running' ? 'pause' : 'play'} disabled={!live} onClick={p.onPlayPause} title="Pause / resume (P)" />
        <Button small icon="stop" disabled={!live} onClick={p.onStop} title="Stop and reset" />
        <Segmented size="sm" value={String(p.speed)} onChange={(v) => p.onSpeed(Number(v))} options={SPEEDS.map((s) => ({ value: String(s), label: `${s}×` }))} />
        <Button small kind="danger" icon="bell" disabled={!live} onClick={p.onEvacuateAll} title="Sound the site-wide evacuation alarm">Evacuate site</Button>
      </div>
    </header>
  );
}
