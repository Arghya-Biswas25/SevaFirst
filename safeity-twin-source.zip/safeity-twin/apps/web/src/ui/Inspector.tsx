import { Button, Chip, Empty, Kpi, Section } from '@twin/ui-kit';
import { spaceKind, wingStoreyTemplate } from '@twin/twin-data';
import type { PickResult } from '@twin/render';
import type { Snapshot } from '@twin/sim-runtime';
import { ds, twin } from '../app/core';
import { fmtInt, fmtTime } from '../app/format';

const DAMAGE = ['None', 'Slight', 'Moderate', 'Extensive', 'Collapsed'];
const BURN = ['—', 'Burning (growing)', 'Fully developed', 'Burnt out'];

export function wingPersons(wi: number): number {
  const w = twin.wings[wi];
  let n = 0;
  for (const f of w.flatIds) n += ds.typologies.units[twin.flats[f].unit]?.personsNominal ?? 0;
  return n;
}

interface Props {
  sel: PickResult | null;
  snap: Snapshot | null;
  onWalk: (p: PickResult) => void;
  onFly: (p: PickResult) => void;
  onCut: (storey: number | null) => void;
  onSimulate: (p: PickResult) => void;
}

export function Inspector({ sel, snap, onWalk, onFly, onCut, onSimulate }: Props) {
  if (!sel || sel.wing === undefined) {
    return <Empty icon="info">Click a building or a room to inspect it. Right-click anywhere to start a simulation there. Double-click to walk in.</Empty>;
  }
  const w = twin.wings[sel.wing];
  const g = sel.spaceId;
  const live = (() => {
    if (!snap || g === undefined) return null;
    const ids = snap.spaces.ids;
    for (let k = 0; k < ids.length; k++) if (ids[k] === g) return { temp: snap.spaces.temp[k], soot: snap.spaces.soot[k], burn: snap.spaces.burn[k], damage: snap.spaces.damage[k] };
    return { temp: 20, soot: 0, burn: 0, damage: 0 };
  })();
  const vis = live ? (live.soot * 8.7 < 0.01 ? 300 : Math.min(300, 3 / (8.7 * live.soot))) : 300;
  const flat = g !== undefined && twin.space.flat[g] >= 0 ? twin.flats[twin.space.flat[g]] : null;
  const unit = flat ? ds.typologies.units[flat.unit] : null;
  const clear = snap?.evac.wingClear.find((c) => c.wing === w.id);
  const wd = snap ? snap.wingDamage[w.idx] : 0;
  const st = g !== undefined ? wingStoreyTemplate(w, sel.storey ?? 0).spaces[twin.space.t[g]] : null;
  return (
    <div className="inspector">
      <div className="insp-head">
        <div className="insp-id">{w.id}</div>
        <div>
          <div className="insp-title">{w.typology.name}</div>
          <div className="muted small">{w.typology.code} · {w.storeys === 8 ? 'G+7' : 'G+5'} · {w.status}{w.massingOnly ? ' · massing only' : ''}</div>
        </div>
      </div>
      <div className="row-btns">
        <Button small icon="target" onClick={() => onFly(sel)}>Fly to</Button>
        {!w.massingOnly && <Button small icon="walk" onClick={() => onWalk(sel)}>Walk in</Button>}
        {!w.massingOnly && sel.storey !== undefined && <Button small icon="scissors" onClick={() => onCut(sel.storey!)}>Cut at floor {sel.storey === 0 ? 'G' : sel.storey}</Button>}
        <Button small kind="primary" icon="fire" onClick={() => onSimulate(sel)}>Simulate…</Button>
      </div>
      {g !== undefined && st && (
        <Section title={<>Space · {st.name}</>}>
          <dl className="dl">
            <dt>Where</dt><dd>{sel.label}</dd>
            <dt>Kind</dt><dd>{spaceKind(twin, g)}{st.roomRole ? ` (${st.roomRole})` : ''}</dd>
            <dt>Area</dt><dd>{twin.space.area[g].toFixed(1)} m² · {twin.space.volume[g].toFixed(0)} m³</dd>
            <dt>Floor</dt><dd>{sel.storey === 0 ? 'Ground' : sel.storey} · level +{((sel.storey ?? 0) * twin.storeyH).toFixed(1)} m</dd>
            {flat && unit && (<><dt>Flat</dt><dd>{flat.key} · {unit.name} · RERA carpet {flat.reraCarpet_m2.toFixed(1)} m²</dd></>)}
          </dl>
          {live && (
            <div className="kpis k4">
              <Kpi label="Temperature" value={`${live.temp.toFixed(0)}°C`} tone={live.temp > 60 ? 'bad' : live.temp > 40 ? 'warn' : 'good'} />
              <Kpi label="Visibility" value={vis >= 300 ? 'clear' : `${vis.toFixed(1)} m`} tone={vis < 5 ? 'bad' : vis < 10 ? 'warn' : 'good'} />
              <Kpi label="Fire" value={BURN[live.burn]} tone={live.burn === 1 || live.burn === 2 ? 'bad' : 'muted'} />
              <Kpi label="Structure" value={DAMAGE[live.damage]} tone={live.damage >= 3 ? 'bad' : live.damage ? 'warn' : 'good'} />
            </div>
          )}
        </Section>
      )}
      <Section title="Building">
        <dl className="dl">
          <dt>Footprint</dt><dd>{w.L.toFixed(1)} × {w.W.toFixed(1)} m · height {w.height.toFixed(1)} m</dd>
          <dt>Orientation</dt><dd>axis bearing {w.pose.bearing.toFixed(1)}° · centre E {w.pose.E.toFixed(1)}, N {w.pose.N.toFixed(1)}</dd>
          <dt>Flats</dt><dd>{w.flatIds.length} · design occupancy ~{fmtInt(wingPersons(w.idx))} people</dd>
          <dt>Stairs / lifts</dt><dd>{w.tpl.typical.stairs.length} / {w.tpl.typical.lifts.length}{w.tpl.typical.stairs.length === 1 ? ' — single escape stair' : ''}</dd>
          <dt>Data</dt><dd>{ds.site.dataLevel}{w.building.confidence ? ` · ${w.building.confidence} confidence` : ''} · {w.building.source ?? 'master plan + floor plan pages'}</dd>
          {snap && (<><dt>Damage</dt><dd><Chip tone={wd >= 3 ? 'bad' : wd ? 'warn' : 'good'}>{DAMAGE[wd]}</Chip></dd></>)}
          {clear && (<><dt>Evacuation</dt><dd>{clear.inside} still inside of {clear.alerted} alerted{clear.clearedAt !== null ? ` · cleared at ${fmtTime(clear.clearedAt)}` : ''}</dd></>)}
        </dl>
      </Section>
    </div>
  );
}
