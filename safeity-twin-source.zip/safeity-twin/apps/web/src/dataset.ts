/**
 * The site dataset, bundled at build time. Swapping in an L2 (sanctioned CAD) or
 * L3 (as-built) dataset means replacing these files; nothing else changes.
 */
import type { SiteDataset } from '@twin/twin-schema';
import site from '../../../data/sites/adora-de-goa/site.json?raw';
import typologies from '../../../data/sites/adora-de-goa/typologies.json?raw';
import buildings from '../../../data/sites/adora-de-goa/buildings.json?raw';
import streets from '../../../data/sites/adora-de-goa/streets.geojson?raw';
import amenities from '../../../data/sites/adora-de-goa/amenities.json?raw';
import resources from '../../../data/sites/adora-de-goa/resources.json?raw';
import occupancy from '../../../data/sites/adora-de-goa/occupancy.json?raw';
import rules from '../../../data/sites/adora-de-goa/rules/nbc-2016-part4.json?raw';

export function loadDataset(): SiteDataset {
  return {
    site: JSON.parse(site),
    typologies: JSON.parse(typologies),
    buildings: JSON.parse(buildings),
    streets: JSON.parse(streets),
    amenities: JSON.parse(amenities),
    resources: JSON.parse(resources),
    occupancy: JSON.parse(occupancy),
    rules: JSON.parse(rules),
  };
}
