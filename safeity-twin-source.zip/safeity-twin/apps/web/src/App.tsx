import { useCallback, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Tabs } from '@twin/ui-kit';
import { SimClient, type Snapshot } from '@twin/sim-runtime';
// bundled into the page as a blob worker, so the built app is a single HTML file
import SimWorker from '@twin/sim-runtime/worker?worker&inline';
import type { SimEvent } from '@twin/hazard-sdk';
import type { HazardSpec, Scenario } from '@twin/twin-schema';
import type { LayerName, PickResult } from '@twin/render';
import { KEY_HELP, type CameraMode } from '@twin/interaction';
import { ds, twin, twinBuildMs } from './app/core';
import type { Preset } from './app/scenarios';
import { fmtTime } from './app/format';
import { Viewport, type ViewportApi } from './ui/Viewport';
import { TopBar, type SimStatus } from './ui/TopBar';
import { BuildingsTab, LayersTab, ScenariosTab, type ViewState } from './ui/LeftDock';
import { Inspector } from './ui/Inspector';
import { EvacPanel, LogPanel, ResponsePanel } from './ui/LivePanels';
import { ContextMenu } from './ui/ContextMenu';
import { SimWindow, type RunSettings } from './ui/SimWindow';

type LeftTab = 'scenarios' | 'buildings' | 'layers';
type RightTab = 'inspect' | 'response' | 'evac' | 'log';
interface Toast { id: number; text: string; level: string }

const DEFAULT_VIEW: ViewState = {
  xray: false, interiors: false, cut: null,
  layers: { labels: true, streets: true, people: true, hazards: true, routes: true, vehicles: true, assembly: true },
};

let toastSeq = 0;

export function App() {
  const api = useRef<ViewportApi | null>(null);
  const sim = useRef<SimClient | null>(null);
  const activeRef = useRef<Scenario | null>(null);
  const [vpReady, setVpReady] = useState(false);
  const [simReady, setSimReady] = useState(false);
  const [simMode, setSimMode] = useState('worker');
  const [snap, setSnap] = useState<Snapshot | null>(null);
  const [events, setEvents] = useState<SimEvent[]>([]);
  const [status, setStatus] = useState<SimStatus>('booting');
  const [speed, setSpeed] = useState(10);
  const [hover, setHover] = useState<{ p: PickResult; x: number; y: number } | null>(null);
  const [sel, setSel] = useState<PickResult | null>(null);
  const [menu, setMenu] = useState<{ p: PickResult | null; x: number; y: number } | null>(null);
  const [win, setWin] = useState<{ hazard: string; origin: PickResult; x: number; y: number } | null>(null);
  const [draft, setDraft] = useState<HazardSpec[]>([]);
  const [settings, setSettings] = useState<RunSettings>({ occupancy: 'weekday-night', seed: 42, launchedOnly: false, disabled: [], windSpeed: 4, windFrom: 250 });
  const [view, setView] = useState<ViewState>(DEFAULT_VIEW);
  const [cam, setCam] = useState<{ mode: CameraMode; ghost: boolean; storey: number }>({ mode: 'orbit', ghost: true, storey: 0 });
  const [left, setLeft] = useState<LeftTab>('scenarios');
  const [right, setRight] = useState<RightTab>('inspect');
  const [fps, setFps] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((text: string, level = 'info') => {
    const id = ++toastSeq;
    setToasts((t) => [...t.slice(-3), { id, text, level }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5200);
  }, []);

  // ---------------------------------------------------------------- simulation client
  useEffect(() => {
    const c = new SimClient(ds, { createWorker: () => new SimWorker({ name: 'twin-sim' }) });
    sim.current = c;
    c.onReady = (_stats, mode) => {
      setSimReady(true);
      setSimMode(mode);
      setStatus('idle');
      if (mode === 'inline') toast('Background workers are blocked here, so the simulation runs on the main thread.', 'warn');
    };
    c.onSnapshot = (s) => {
      if (!activeRef.current) return;
      api.current?.r.applySnapshot(s);
      setSnap(s);
      if (s.events.length) {
        setEvents((ev) => [...ev, ...s.events].slice(-800));
        for (const e of s.events.filter((x) => x.level === 'critical').slice(0, 2)) toast(`${fmtTime(e.t)} · ${e.text}`, 'critical');
      }
    };
    c.onError = (m) => toast(m, 'warn');
    return () => c.dispose();
  }, [toast]);

  useEffect(() => {
    const id = setInterval(() => setFps(api.current?.r.fps ?? 0), 1000);
    return () => clearInterval(id);
  }, []);

  // ---------------------------------------------------------------- view state -> renderer
  useEffect(() => {
    const r = api.current?.r;
    if (!r) return;
    r.setXray(view.xray);
    r.setInteriors(view.interiors);
    r.setCut(view.cut);
    for (const [k, on] of Object.entries(view.layers)) r.setLayer(k as LayerName, on);
  }, [view, vpReady]);

  // ---------------------------------------------------------------- camera helpers
  const flyTo = useCallback((p: PickResult) => {
    const a = api.current;
    if (!a) return;
    if (p.wing !== undefined && p.spaceId === undefined) {
      const w = twin.wings[p.wing];
      a.cam.flyTo(new THREE.Vector3(w.pose.E, w.height * 0.4, -w.pose.N), Math.max(45, w.L * 1.4));
    } else a.cam.flyTo(new THREE.Vector3(p.E, p.up, -p.N), p.kind === 'outdoor' ? 80 : 32);
  }, []);

  const focusWing = useCallback((wi: number) => {
    const w = twin.wings[wi];
    const p: PickResult = { kind: 'building', E: w.pose.E, N: w.pose.N, up: 0, buildingId: w.id, wing: wi, label: `${w.id} · ${w.typology.name}` };
    setSel(p);
    api.current?.r.setSelection(p);
    flyTo(p);
  }, [flyTo]);

  const walkIn = useCallback((p: PickResult) => {
    const a = api.current;
    if (!a) return;
    let E = p.E;
    let N = p.N;
    if (p.spaceId !== undefined) {
      E = twin.space.E[p.spaceId];
      N = twin.space.N[p.spaceId];
    }
    // face along the wing axis (corridors run along it)
    const yaw = p.wing !== undefined ? -THREE.MathUtils.degToRad(twin.wings[p.wing].pose.bearing) : undefined;
    setView((v) => ({ ...v, interiors: true, xray: false, cut: null }));
    a.cam.walkAt(E, N, p.storey ?? 0, yaw);
  }, []);

  const setCamMode = useCallback((m: CameraMode) => {
    const a = api.current;
    if (!a) return;
    if (m === 'walk') {
      const t = a.cam.orbit.target;
      setView((v) => ({ ...v, interiors: true }));
      a.cam.walkAt(t.x, -t.z, 0);
    } else a.cam.setMode(m);
  }, []);

  // ---------------------------------------------------------------- scenario control
  const run = useCallback((scn: Scenario, launchedOnly: boolean) => {
    const c = sim.current;
    if (!c) return;
    api.current?.r.resetOverlays();
    activeRef.current = scn;
    setEvents([]);
    setSnap(null);
    c.setSpeed(speed);
    c.start(scn, { launchedOnly });
    api.current?.r.setWind(scn.wind?.speed_ms ?? 4, scn.wind?.fromDeg ?? 250);
    setStatus('running');
    setRight('response');
  }, [speed]);

  const buildScenario = useCallback((hz: HazardSpec[]): Scenario => ({
    id: `custom-${Date.now().toString(36)}`, version: 1, seed: settings.seed, occupancy: settings.occupancy, hazards: hz,
    resources: { disabled: settings.disabled }, wind: { speed_ms: settings.windSpeed, fromDeg: settings.windFrom },
  }), [settings]);

  const runPreset = useCallback((p: Preset) => {
    const scn = p.build(twin);
    scn.resources = { ...(scn.resources ?? {}), disabled: settings.disabled };
    setDraft(scn.hazards);
    setSettings((s) => ({ ...s, occupancy: scn.occupancy, seed: scn.seed }));
    run(scn, settings.launchedOnly);
    if (p.focus) focusWing(twin.wingById.get(p.focus)!);
    else api.current?.cam.view('home');
    toast(`Running “${p.title}”`);
  }, [run, settings, focusWing, toast]);

  const stop = useCallback(() => {
    sim.current?.stop();
    activeRef.current = null;
    setStatus('idle');
    setSnap(null);
    api.current?.r.resetOverlays();
  }, []);

  const playPause = useCallback(() => {
    if (!activeRef.current) return;
    if (status === 'running') {
      sim.current?.pause();
      setStatus('paused');
    } else {
      sim.current?.resume();
      setStatus('running');
    }
  }, [status]);

  const openSim = useCallback((p: PickResult, hazard?: string, x?: number, y?: number) => {
    const h = hazard ?? (p.kind === 'space' ? 'fire' : p.kind === 'building' ? 'collapse' : 'earthquake');
    setMenu(null);
    setWin({ hazard: h, origin: p, x: x ?? Math.max(16, window.innerWidth - 820), y: y ?? 96 });
  }, []);

  // ---------------------------------------------------------------- keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'SELECT' || el.tagName === 'TEXTAREA')) return;
      const k = e.key.toLowerCase();
      if (k === 'escape') {
        if (menu) setMenu(null);
        else if (win) setWin(null);
        else if (cam.mode !== 'orbit') setCamMode('orbit');
        else {
          setSel(null);
          api.current?.r.setSelection(null);
        }
      }
      if (cam.mode === 'orbit' || !['w', 'a', 's', 'd', 'q', 'e', 'r', 'f', 'g'].includes(k)) {
        if (k === '1') setCamMode('orbit');
        if (k === '2') setCamMode('fly');
        if (k === '3') setCamMode('walk');
        if (k === 'x') setView((v) => ({ ...v, xray: !v.xray }));
        if (k === 'i') setView((v) => ({ ...v, interiors: !v.interiors }));
        if (k === 'p') playPause();
        if (k === 'h') api.current?.cam.view('home');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [menu, win, cam.mode, setCamMode, playPause]);

  const live = status === 'running' || status === 'paused';
  const p1 = snap?.recommendations.filter((r) => r.priority === 1).length ?? 0;
  const hoverLive = (() => {
    if (!hover || !snap || hover.p.spaceId === undefined) return null;
    const ids = snap.spaces.ids;
    for (let k = 0; k < ids.length; k++) {
      if (ids[k] !== hover.p.spaceId) continue;
      const soot = snap.spaces.soot[k];
      const vis = soot * 8.7 < 0.01 ? 300 : Math.min(300, 3 / (8.7 * soot));
      return `${snap.spaces.temp[k].toFixed(0)}°C · visibility ${vis >= 300 ? 'clear' : `${vis.toFixed(1)} m`}${snap.spaces.burn[k] === 1 || snap.spaces.burn[k] === 2 ? ' · burning' : ''}`;
    }
    return null;
  })();

  return (
    <div className="app">
      <TopBar
        cam={cam.mode} ghost={cam.ghost} storey={cam.storey} view={view} status={status} simT={snap?.t ?? 0} speed={speed}
        onCam={setCamMode}
        onGhost={() => {
          const c = api.current?.cam;
          if (!c) return;
          c.ghost = !c.ghost;
          setCam((s) => ({ ...s, ghost: c.ghost }));
        }}
        onHome={() => api.current?.cam.view('home')}
        onTop={() => api.current?.cam.view('top')}
        onView={setView}
        onPlayPause={playPause}
        onStop={stop}
        onSpeed={(s) => {
          setSpeed(s);
          sim.current?.setSpeed(s);
        }}
        onEvacuateAll={() => {
          sim.current?.alertAll();
          toast('Site-wide evacuation alarm sounded');
        }}
      />
      <aside className="dock left">
        <Tabs value={left} onChange={setLeft} tabs={[
          { id: 'scenarios', label: 'Simulate', icon: 'fire' },
          { id: 'buildings', label: 'Buildings', icon: 'building' },
          { id: 'layers', label: 'Layers', icon: 'layers' },
        ]} />
        <div className="dock-body">
          {left === 'scenarios' && (
            <ScenariosTab running={live} draft={draft}
              onPreset={runPreset}
              onLoadPreset={(p) => {
                const scn = p.build(twin);
                setDraft(scn.hazards);
                setSettings((s) => ({ ...s, occupancy: scn.occupancy, seed: scn.seed }));
                if (p.focus) focusWing(twin.wingById.get(p.focus)!);
                toast(`Loaded “${p.title}” into your scenario. Right-click to add more hazards.`);
              }}
              onRunDraft={() => run(buildScenario(draft), settings.launchedOnly)}
              onRemoveDraft={(i) => setDraft((d) => d.filter((_, j) => j !== i))}
              onClearDraft={() => setDraft([])}
            />
          )}
          {left === 'buildings' && <BuildingsTab selected={sel?.wing} onPick={focusWing} />}
          {left === 'layers' && <LayersTab view={view} onView={setView} />}
        </div>
      </aside>
      <main className="stage">
        <Viewport
          onReady={(a) => {
            api.current = a;
            setVpReady(true);
          }}
          onHover={(p, x, y) => setHover(p ? { p, x, y } : null)}
          onSelect={(p) => {
            setSel(p);
            api.current?.r.setSelection(p);
            if (p) setRight('inspect');
          }}
          onContext={(p, x, y) => {
            setHover(null);
            setMenu({ p, x, y });
          }}
          onWalk={walkIn}
          onCamera={(c) => setCam({ mode: c.mode, ghost: c.ghost, storey: c.storey })}
        />
        {hover && !menu && (
          <div className="tooltip" style={{ left: hover.x + 14, top: hover.y + 16 }}>
            <div>{hover.p.label}</div>
            {hoverLive && <div className="tt-live">{hoverLive}</div>}
          </div>
        )}
        {!simReady && (
          <div className="boot">
            <div className="spinner" />
            <div>
              <b>Preparing the simulation engine…</b>
              <div className="muted small">{twin.wings.length} wings, {twin.nSpaces.toLocaleString('en-IN')} spaces built in {twinBuildMs} ms. Building the navigation graph in the background.</div>
            </div>
          </div>
        )}
        <div className="toasts">
          {toasts.map((t) => <div key={t.id} className={`toast lv-${t.level}`}>{t.text}</div>)}
        </div>
        <div className="statusbar">
          <span className="sb-help">{KEY_HELP[cam.mode]}</span>
          {cam.mode === 'fly' && <span>speed {Math.round(api.current?.cam.flySpeed ?? 14)} m/s · {cam.ghost ? 'ghost' : 'solid'}</span>}
          <span className="sb-right">{sel?.label ?? 'Nothing selected'}</span>
          <span className="sb-perf" title={`Simulation runs in ${simMode === 'worker' ? 'a background worker' : 'the main thread (workers blocked)'}`}>{fps} fps · {(snap?.stepMs ?? 0).toFixed(1)} ms/step</span>
        </div>
      </main>
      <aside className="dock right">
        <Tabs value={right} onChange={setRight} tabs={[
          { id: 'inspect', label: 'Inspect' },
          { id: 'response', label: 'Response', badge: p1 || undefined },
          { id: 'evac', label: 'People' },
          { id: 'log', label: 'Log', badge: events.filter((e) => e.level === 'critical').length || undefined },
        ]} />
        <div className="dock-body">
          {right === 'inspect' && <Inspector sel={sel} snap={snap} onWalk={walkIn} onFly={flyTo} onSimulate={(p) => openSim(p)}
            onCut={(s) => setView((v) => ({ ...v, cut: s, interiors: true }))} />}
          {right === 'response' && <ResponsePanel snap={snap} onFocusWing={focusWing} />}
          {right === 'evac' && <EvacPanel snap={snap} />}
          {right === 'log' && <LogPanel events={events} onFocusWing={focusWing} />}
        </div>
      </aside>
      {menu && (
        <ContextMenu p={menu.p} x={menu.x} y={menu.y} running={live}
          onClose={() => setMenu(null)}
          onSimulate={(h) => menu.p && openSim(menu.p, h, menu.x + 12, menu.y - 20)}
          onInspect={() => {
            if (!menu.p) return;
            setSel(menu.p);
            api.current?.r.setSelection(menu.p);
            setRight('inspect');
            setMenu(null);
          }}
          onWalk={() => {
            if (menu.p) walkIn(menu.p);
            setMenu(null);
          }}
          onFlyTo={() => {
            if (menu.p) flyTo(menu.p);
            setMenu(null);
          }}
        />
      )}
      {win && (
        <SimWindow
          hazardId={win.hazard} origin={win.origin} x={win.x} y={win.y} running={live} simT={snap?.t ?? 0} draft={draft} settings={settings}
          onHazard={(h) => setWin({ ...win, hazard: h })}
          onAdd={(spec) => {
            setDraft((d) => [...d, spec]);
            toast(`Added ${spec.type} at ${spec.origin.label ?? 'site'} to your scenario (${draft.length + 1}).`);
            setLeft('scenarios');
          }}
          onRun={(spec) => {
            const hz = spec ? [...draft, spec] : draft;
            setDraft(hz);
            run(buildScenario(hz), settings.launchedOnly);
            setWin(null);
          }}
          onInject={(spec) => {
            sim.current?.inject(spec);
            toast(`Injected ${spec.type} at ${spec.origin.label ?? 'site'}`);
            setWin(null);
          }}
          onRemoveDraft={(i) => setDraft((d) => d.filter((_, j) => j !== i))}
          onSettings={setSettings}
          onClose={() => setWin(null)}
        />
      )}
    </div>
  );
}
