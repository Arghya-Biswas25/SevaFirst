# Adora de Goa — Digital Twin

A to-scale 3D digital twin of the Adora de Goa township (Provident Housing, Chicalim–Dabolim, South Goa) with
an all-hazards simulator. Right-click anywhere in the model to start a fire, a building collapse, an earthquake
or a power failure at that spot. The app evacuates every household along the most convenient tenable route,
dispatches fire tenders, ambulances and rescue teams with an optimiser, and explains each decision.

Built from the PRD "Township Digital Twin" (Claude Docs). This repository is Milestone 1: a working vertical
slice of every layer in the PRD, on L1 data calibrated from the developer's floor-plan brochure (`ePlan.pdf`).

## Run it

```bash
npm install
npm run dev          # http://localhost:5173
```

Production build:

```bash
npm run build        # apps/web/dist
npm run preview      # http://localhost:4173
```

`npm run check` runs the typecheck, the test suite and the production build.

Requires Node 20 or newer. The built app is static files and runs from any web server (it cannot run from
`file://` because browsers block module workers there).

## Using the app

| Action | How |
| --- | --- |
| Orbit the site | Left-drag rotate, Shift or middle-drag pan, wheel zoom, W A S D pan |
| Hover through buildings | **Hover** mode (key 2): left-drag look, W A S D move, Q/E down/up, G toggles ghost/solid |
| Walk a floor | **Walk** mode (key 3) or double-click a room: W A S D walk, PgUp/PgDn change floor |
| See inside | **Interiors** (I), **X-ray** (X), or cut the model above a floor |
| Simulate | Right-click a room, building or open ground (long-press on touch), pick a hazard, set parameters, Run |
| Stack hazards | "Add to scenario" in the simulation window, e.g. two fires two minutes apart |
| Presets | Left dock → Simulate: two fires one tender, mixed-use kitchen fire, DBE and MCE earthquakes, progressive collapse, grid failure |
| Follow the response | Right dock: Response (dispatch with reasons and next-best option, recommendations), People (evacuation status, assembly points, wing clearance), Log |

## Repository layout

```
apps/web/                  React shell: viewport, docks, context menu, simulation window
packages/
  core/                    RNG, geometry helpers, fixed-step clock, event bus
  twin-schema/             dataset and scenario types + validation
  twin-data/               typology templates → per-room twin (20,838 spaces, 1,912 flats)
  geometry/                shell and interior meshes, ribbons, colours
  render/                  three.js scene: instancing, picking, hazard/people/vehicle overlays
  interaction/             camera modes (orbit, hover/fly, walk) with collision
  nav/                     pedestrian + vehicle navigation graph, A*, multi-source fields
  hazard-sdk/              HazardPlugin contract and the shared FieldStore
  hazards/{fire,collapse,earthquake,power}/   v1 hazard plugins
  crowd/                   household evacuation (convenience routing, queues, shelter-in-place)
  dispatch/                responder optimiser (Hungarian assignment, re-solved every 5 s)
  advisor/                 rule-based recommendations with reasons and sources
  sim-runtime/             engine, worker, protocol, hazard registry, inline fallback
  ui-kit/                  shared React primitives
data/sites/adora-de-goa/   the site dataset (site, typologies, buildings, streets, amenities, resources, occupancy, rules)
tools/ingest-eplan/        scripts that measured the brochure and generated the dataset
tests/                     Vitest suites (dataset, navigation, simulation, runtime)
docs/                      architecture, plugin guide, data notes, build status
```

## Adding a hazard

Write a `HazardPlugin` in `packages/hazards/<id>`, register it in `packages/sim-runtime/src/registry.ts`, and it
appears in the right-click menu and the simulation window with a form generated from its parameters. Routing,
evacuation, dispatch and advice react to what it writes into the shared field. See `docs/PLUGIN_GUIDE.md`.

## Accuracy

Geometry is L1: building positions, orientations and footprints are measured from the brochure master plan
(about 0.64 m per pixel, cross-checked four ways) and floor plans; interiors are generated from the published
unit types and sized to RERA carpet areas. Positions are within about ±5 m and bearings within about ±2°.
Replacing the files in `data/sites/adora-de-goa` with sanctioned CAD (L2) or an as-built survey (L3) upgrades
the twin without code changes. The fire, structural and seismic models are engineering approximations for
planning and training, not certified analyses. See `docs/DATA.md` and `docs/STATUS.md`.
